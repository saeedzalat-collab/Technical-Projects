package com.appsdeveloperblog.app.ws.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.appsdeveloperblog.app.ws.io.Repository.UserRepository;
import com.appsdeveloperblog.app.ws.io.entity.UserEntity;
import com.appsdeveloperblog.app.ws.shared.Utils;
import com.appsdeveloperblog.app.ws.shared.dto.AddressDTO;
import com.appsdeveloperblog.app.ws.shared.dto.UserDto;

class UserServiceImplTest {

	//we cannot mock it because it is the class under test
	@InjectMocks
	UserServiceImpl userService; //we import it here to be able to call getUser method
	
	@Mock
	UserRepository userRepository;
	
	@Mock
	Utils utils;
	
	@Mock
	BCryptPasswordEncoder bCryptPasswordEncoder;
	
	String userID = "hhhrhrhrhhrh";
	String encryptedPassword = "h4h4hgkjk4jk4";
	
	UserEntity userEntity;
	
	@BeforeEach
	void setUp() throws Exception{
		MockitoAnnotations.openMocks(this);
		
		userEntity = new UserEntity();
		userEntity.setId(1L);
		userEntity.setFirstName("Saeed");
		userEntity.setUserId(userID);
		userEntity.setEncryptedPassword(encryptedPassword);
	}
	
	@Test
	final void testGetUser() {
		
		
		when(userRepository.findByEmail(anyString())).thenReturn(userEntity);
		
		UserDto userDto = userService.getUser("test@gmail.com");
		
		assertNotNull(userDto); // if the userDto is Null for any reason this method will not pass
		assertEquals("Saeed", userDto.getFirstName());	
	}
	
	@Test
	final void testGetUser_UsernameNotFoundException()
	{
		when(userRepository.findByEmail(anyString())).thenReturn(null);
		
		assertThrows(UsernameNotFoundException.class, 
				()->{
					userService.getUser("test@gmail.com");
				});
	}
	
	@Test
	final void testCreateUser_CreateUserServiceException()
	{
		when(userRepository.findByEmail(anyString())).thenReturn(userEntity);
		
		AddressDTO addressDto = new AddressDTO();
		addressDto.setType("shipping");
		
		List<AddressDTO> addresses = new ArrayList<>();
		addresses.add(addressDto);
		
		UserDto userDto = new UserDto();
		userDto.setAddresses(addresses);
		
		assertThrows(RuntimeException.class, 
				()->{
					userService.createUser(userDto);
				});
	}
	
	@Test
	final void TestCreateUser()
	{

		when(userRepository.findByEmail(anyString())).thenReturn(null);
		when(utils.generateAddressId(anyInt())).thenReturn("hhgshgdhsgh6667");
		when(utils.generateUserId(anyInt())).thenReturn(userID);
		when(bCryptPasswordEncoder.encode(anyString())).thenReturn(encryptedPassword);
		when(userRepository.save(any(UserEntity.class))).thenReturn(userEntity);
		
		AddressDTO addressDto = new AddressDTO();
		addressDto.setType("shipping");
		
		List<AddressDTO> addresses = new ArrayList<>();
		addresses.add(addressDto);
		
		UserDto userDto = new UserDto();
		userDto.setAddresses(addresses);
		
		UserDto storedUserDetails = userService.createUser(userDto);
		
		assertNotNull(storedUserDetails); 
		assertEquals(userEntity.getFirstName(), storedUserDetails.getFirstName());	
	}

}
