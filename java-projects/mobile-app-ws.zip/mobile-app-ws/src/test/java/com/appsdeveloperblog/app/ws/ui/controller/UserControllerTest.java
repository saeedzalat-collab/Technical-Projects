package com.appsdeveloperblog.app.ws.ui.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import com.appsdeveloperblog.app.ws.shared.dto.AddressDTO;
import com.appsdeveloperblog.app.ws.service.UserService;
import com.appsdeveloperblog.app.ws.service.impl.UserServiceImpl;
import com.appsdeveloperblog.app.ws.shared.dto.UserDto;
import com.appsdeveloperblog.app.ws.ui.model.response.UserRest;

class UserControllerTest {

	@InjectMocks
	userController userController;
	
	@Mock
	UserServiceImpl userService;
	
	UserDto userDto;
	
	final String USER_ID = "SASAJSjhj";
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
		userDto = new UserDto();
		userDto.setFirstName("saeed");
		userDto.setLastName("Zalat");
		userDto.setAddresses(getAddressesDto());
		userDto.setEmail("saeed@gmail.com");
		userDto.setEmailVerificationStatus(Boolean.FALSE);
		userDto.setUserId(USER_ID);
		userDto.setEncryptedPassword("basdbbda7");
		
	}

	@Test
	final void testGetUser() {
		
		when(userService.getUserByUserId(anyString())).thenReturn(userDto);
		UserRest userRest = userController.getUser(USER_ID);
		assertNotNull(userRest);
		assertEquals(USER_ID, userRest.getUserId());
		assertEquals(userDto.getFirstName(), userRest.getFirstName());
		assertEquals(userDto.getLastName(), userRest.getLastName());
		assertTrue(userDto.getAddresses().size() == userRest.getAddresses().size());
		
		
	}
	
	private List<AddressDTO> getAddressesDto() {
	    AddressDTO addressDto = new AddressDTO();
	    addressDto.setType("shipping");
	    addressDto.setCity("Vancouver");
	    addressDto.setCountry("Canada");
	    addressDto.setPostalCode("ABC123");
	    addressDto.setStreetName("123 Street name");

	    AddressDTO billingAddressDto = new AddressDTO();
	    billingAddressDto.setType("billing");
	    billingAddressDto.setCity("Vancouver");
	    billingAddressDto.setCountry("Canada");
	    billingAddressDto.setPostalCode("ABC123");
	    billingAddressDto.setStreetName("123 Street name");

	    List<AddressDTO> addresses = new ArrayList<>();
	    addresses.add(addressDto);
	    addresses.add(billingAddressDto);

	    return addresses;
	}


}
