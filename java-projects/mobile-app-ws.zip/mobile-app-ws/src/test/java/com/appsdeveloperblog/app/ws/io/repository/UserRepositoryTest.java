package com.appsdeveloperblog.app.ws.io.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.appsdeveloperblog.app.ws.io.Repository.UserRepository;
import com.appsdeveloperblog.app.ws.io.entity.UserEntity;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class UserRepositoryTest {

	@Autowired
	UserRepository userRepository;
	static boolean recordsCreated = false;
	
	@BeforeEach
	void setUp() throws Exception {
		
		if(!recordsCreated) createRecord();
	}

	@Test
	final void testGetVerifiedUsers() {
		
		Pageable pageableRequest = PageRequest.of(0, 2);
		Page<UserEntity> pages = userRepository.findAllUsersWithConfirmedEmailAddress(pageableRequest);
		assertNotNull(pages);
		
		List<UserEntity> userEntities = pages.getContent();
		assertNotNull(userEntities);
		assertTrue(userEntities.size() == 1);
	}
	
	@Test
	final void findUserByFirstName()
	{
		String firstName = "saeed";
		List<UserEntity> users = userRepository.findUsersByFirstName(firstName);
		assertNotNull(users);
		assertTrue(users.size() == 1);
		
		UserEntity userEntity = users.get(0);
		assertTrue(userEntity.getFirstName().equals(firstName));
	}
	
	@Test
	final void findUserByLastName()
	{
		String lastName = "Mostafa";
		List<UserEntity> users = userRepository.findUsersByLastName(lastName);
		assertNotNull(users);
		assertTrue(users.size() == 1);
		
		UserEntity userEntity = users.get(0);
		assertTrue(userEntity.getLastName().equals(lastName));
	}
	
	@Test
	void testUpdateUserEmailVerificationStatus()
	{
		boolean newEmailVerificationStatus = true;
		userRepository.updateUserEmailVerificationStatus(newEmailVerificationStatus, "asda2dsa");
		
		UserEntity storedDetails = userRepository.findByUserId("asda2dsa");
		assertEquals(storedDetails.getEmailVerificationStatus(), newEmailVerificationStatus);
	}
	
	@Test
	void testFindUserEntityByUserId()
	{
		UserEntity userEntity = userRepository.findUserEntityByUserId("asda2dsa");
		assertNotNull(userEntity);
		
		assertTrue(userEntity.getUserId().equals("asda2dsa"));
	}
	
	@Test 
	void testGetUserEntityFullNameById()
	{
		List<Object[]> records = userRepository.getUserEntityFullNameById("asda2dsa");
		
		assertNotNull(records);
		assertTrue(records.size() == 1);
		
		Object[] userDetails = records.get(0);
		String firstName = String.valueOf(userDetails[0]);
		String lastName = String.valueOf(userDetails[1]);
		
		assertNotNull(firstName);
		assertNotNull(lastName);
		
	}
	
	@Test
	void testUpdateUserEntityEmailVerificationStatus()
	{
		boolean newEmailVerificationStatus = true;
		userRepository.updateUserEntityEmailVerificationStatus(newEmailVerificationStatus, "asda2dsa");
		
		UserEntity storedDetails = userRepository.findByUserId("asda2dsa");
		assertEquals(storedDetails.getEmailVerificationStatus(), newEmailVerificationStatus);
	}
	
	final void createRecord()
	{
		UserEntity userEntity = new UserEntity();
		userEntity.setFirstName("saeed");
		userEntity.setLastName("Mostafa");
		userEntity.setUserId("asda2dsa");
		userEntity.setEncryptedPassword("sawxx");
		userEntity.setEmail("test@test.com");
		userEntity.setEmailVerificationStatus(true);
		
		userRepository.save(userEntity);
		recordsCreated = true;
	}

}
